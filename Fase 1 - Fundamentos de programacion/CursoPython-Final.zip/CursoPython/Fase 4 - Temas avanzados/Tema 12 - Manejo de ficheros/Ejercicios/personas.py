# -*- coding: utf-8 -*-
"""
Created on Sat Jan 18 18:42:25 2020

@author: Isra
"""
from io import open

def leer():
    try:
        fichero = open("personas.txt", "r",-1,"utf8")
        
        lineas = fichero.readlines()
                
        fichero.close()
        del(fichero)
        
        #  id, nombre, apellido y nacimiento
        personas = []
        
        for linea in lineas:
            campos = linea.replace('\n','').split(";")
            persona = {"id":campos[0], "nombre":campos[1], "apellido":campos[2], "nacimiento":campos[3]}
            personas.append(persona)
        
        #print(personas)
            
        for p in personas:
            print("(id={}) {} {} \t=> {}".format(p['id'], p['nombre'], p['apellido'], p['nacimiento']))
   
    except:
        pass
    
leer()