# -*- coding: utf-8 -*-
"""
Created on Sat Jan 18 20:47:54 2020

@author: Isra
"""
import os
from io import open

def contar(tipo=""):
    
    filename = "contador.txt"
    
    # Comprobacion de existencia del archivo o 
    # si está vacio, se creará con un valor de 0
    if not os.path.exists(filename) or\
           os.path.getsize(filename) == 0:
        print("El archivo no existe, será creado.")
        archivo = open(filename, "w")
        archivo.write("0")
    else: # Si existe leemos el contenido
        archivo = open(filename, "r")
        texto = archivo.read()

    archivo.close()

    try:  
        numero = int(texto)
        
        # Inteligencia de control del contador
        if tipo == "inc":
            numero += 1
        elif tipo == "dec":
            numero -= 1
    
        print(numero)
        
        archivo = open(filename, "w")
        archivo.write(str(numero))
        archivo.close()
    except:
        print("Error: Fichero corrupto.")
            
contar("inc")

# =============================================================================
# from io import open
# import sys
# 
# fichero = open("contador.txt", "a+") 
# fichero.seek(0)
# contenido = fichero.readline()
# 
# if len(contenido) == 0:
#     contenido = "0"
#     fichero.write(contenido)
# 
# fichero.close()
# 
# # Vamos a intentar transformar el texto a un número
# try:
#     contador = int(contenido)
# 
#     # En función de lo que el usuario quiera...
#     if len(sys.argv) == 2:
#         if sys.argv[1] == "inc":
#             contador += 1
#         elif sys.argv[1] == "dec":
#             contador -= 1
# 
#     print(contador)
# 
#     # Finalmente volvemos a escribir los cambios en el fichero
#     fichero = open("contador.txt", "w")
#     fichero.write( str(contador) )
#     fichero.close()
# 
# except:
#     print("Error: Fichero corrupto.")
# =============================================================================
