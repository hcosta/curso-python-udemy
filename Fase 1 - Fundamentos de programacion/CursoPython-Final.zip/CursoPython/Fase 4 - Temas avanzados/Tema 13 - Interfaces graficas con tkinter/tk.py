# -*- coding: utf-8 -*-
"""
Created on Sun Jan 19 21:13:24 2020

@author: Isra
"""

from tkinter import *

root = Tk()

# Entramos en modo bucle. Debe ir abajo del todo.

root.title("Mi primera aplicación")
root.resizable(1,0) # Evitamos la redimension root.resizable(0,0) (ancho,alto)
root.iconbitmap("hola.ico")  #Formato ico para windows.
# En la barra de tareas dicho icono se vería si el programa fuese distribuible
# Con la extensión *.pyw se oculta la terminal y solo muestra la GUI

root.mainloop()
