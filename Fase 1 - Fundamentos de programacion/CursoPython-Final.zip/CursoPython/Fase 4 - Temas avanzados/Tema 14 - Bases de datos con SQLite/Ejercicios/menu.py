# -*- coding: utf-8 -*-
"""
Created on Sun Jan 26 13:48:22 2020

@author: Isra
"""

try:                        # In order to be able to import tkinter for
    from tkinter import *    # either in python 2 or in python 3
except ImportError:
    from Tkinter import *
    
import sqlite3

nombreRestaurante = "Don Candido"

#Raiz
root = Tk(baseName=nombreRestaurante)
root.title(nombreRestaurante)
root.resizable(0,0)
root.iconbitmap('icono.ico')

# Frame y label con imagen. El root siempre adapta su tamaño respecto al widget interior que contiene.
frame = Frame(root,bg="lightblue",bd=2, width = 450, height = 800)
frame.pack(fill=BOTH, expand=True )

# Lateral izquierdo
lateralIzq = Label(frame, text="",bg="lightblue")
lateralIzq.grid(row=0, column=0, padx=2, pady=0, rowspan=6)
lateralIzq.config(width=5)

# Titulo del menu
tituloTop = Label(frame, text="Restaurante {}".format(nombreRestaurante),bg="lightblue")
tituloTop.grid(row=0, column=1, padx=5, pady=0)
tituloTop.config(font=("Verdana",24,"bold italic"), fg="blue")

# Subtitulo
subtituloTop = Label(frame, text="Menú del día",bg="lightblue")
subtituloTop.grid(row=1, column=1, padx=5, pady=0)
subtituloTop.config(font=("Verdana",20,"bold italic"), fg="gray")

# Lateral Derecho
lateralDer = Label(frame, text="",bg="lightblue")
lateralDer.grid(row=0, column=7, padx=2, pady=0, rowspan=6)
lateralDer.config(width=5)

# Espacio
Label(frame,bg="lightblue").grid(row=2, column=1, padx=5, pady=0)

########################
# Conectamos con la base para imprimirlo de forma dinamica
########################

nombreBase= "restaurante"
strCategorias = "categorias"
strPlatos = "platos"

conn = sqlite3.connect(nombreBase+".db")
cursor = conn.cursor()

# Recuperamos todas las categorias
SQLCategorias = "SELECT * FROM {}".format(strCategorias)
categorias = conn.execute(SQLCategorias).fetchall()

#Recorremos todas las categorias y dentro los platos
lastrow=2
lastcolumn=1

for categoria in categorias:
    lastrow += 1
    Label(frame,text=categoria[1],bg="lightblue", font=("Verdana",18,"italic"), fg="black").grid(row=lastrow, column=lastcolumn, padx=5, pady=0)
    
    SQLPlatos = "SELECT * FROM {} WHERE categoria_id={}".format(strPlatos,categoria[0])
    platos = conn.execute(SQLPlatos).fetchall()
    for plato in platos:
        lastrow += 1
        Label(frame,text=plato[1],bg="lightblue", font=("Verdana",12,"italic"), fg="gray").grid(row=lastrow, column=lastcolumn, padx=5, pady=0)
    
    # Espacio
    lastrow += 1
    Label(frame,bg="lightblue").grid(row=lastrow, column=lastcolumn, padx=5, pady=0)
    
# Precio del menú
lastrow += 1
Label(frame,bg="lightblue").grid(row=lastrow, column=lastcolumn, padx=5, pady=0)
Label(frame, text="12€ (IVA incl.)", bg="lightblue", fg="darkgreen", font=("Verdana",16,"bold italic")).grid(row=lastrow, column=lastcolumn, padx=5, pady=0,sticky="e")

# Cerramos la base y objeto
conn.commit()
cursor.close()
conn.close()


root.mainloop()