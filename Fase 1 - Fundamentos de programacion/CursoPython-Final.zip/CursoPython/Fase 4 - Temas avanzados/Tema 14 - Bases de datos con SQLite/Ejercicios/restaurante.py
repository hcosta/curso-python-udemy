# -*- coding: utf-8 -*-
"""
Created on Sat Jan 25 15:48:11 2020

@author: Isra
"""
import sqlite3
import sys
import os

def crear_db():
    # CREAMOS CONEXION. SI NO EXISTE LA BASE SE CREARA
    nombre_base="restaurante"
    conexion = sqlite3.connect(nombre_base + ".db")
    cursor = conexion.cursor()
    
    # CREAMOS LAS TABLAS
    try:
        tabla="categorias"
        cursor.execute("CREATE TABLE " + tabla + """(
                       id INTEGER PRIMARY KEY AUTOINCREMENT,
                       nombre VARCHAR(100) UNIQUE NOT NULL
                        )""")
        # conexion.commit() # Para la creacion de tablas no hace falta
        
    except sqlite3.Error as e:
        messageError = e.args[0]
        
        if "exists" in messageError:
            print("La tabla {} ya existe.".format(tabla) )
    else: # Si todo ocurre correctamente.
        mensaje = "La tabla {} se ha creado correctamente.".format(tabla)
        print(mensaje)
    
    try:
        tabla="platos"
        cursor.execute("CREATE TABLE " + tabla + """(
                       id INTEGER PRIMARY KEY AUTOINCREMENT,
                       nombre VARCHAR(100) UNIQUE NOT NULL, 
                       categoria_id INTEGER NOT NULL,
                       FOREIGN KEY(categoria_id) REFERENCES categoria(id)
                        )""")
        # conexion.commit()
        
    except sqlite3.Error as e:
        messageError = e.args[0]
        
        if "exists" in messageError:
            print("La tabla {} ya existe.".format(tabla) )
    else: # Si todo ocurre correctamente.
        mensaje = "La tabla {} se ha creado correctamente.".format(tabla)
        print(mensaje)
        
    
    # CERRAMOS CONEXION Y OBJETOS

    cursor.close()
    conexion.close()
    
def agregar_categoria():
    # CREAMOS CONEXION. SI NO EXISTE LA BASE SE CREARA
    nombre_base="restaurante"
    conexion = sqlite3.connect(nombre_base + ".db")
    cursor = conexion.cursor()
    
    tabla = "categorias"
    campo_update = "nombre"
    
    categoria = input("Inserte un nombre para la categoría:\n> ")

    if categoria is not None:
        try:
            cursor.execute("INSERT INTO {} ('{}') VALUES ('{}')".format(tabla, campo_update, categoria))
        
            # print(categoria)
            # return
        except sqlite3.Error as e:
            messageError = e.args[0]
            
            if "UNIQUE" in messageError:
                print("\nNo puede insertar valores duplicados, '{}'\n".format(categoria))
        else:
            mensaje = "\nSe ha agregado correctamente la categoria {}.\n".format(categoria)
            print(mensaje)
            conexion.commit()

    cursor.close()
    conexion.close()  

def agregar_plato():
    print("Seleccione una categoria:\n")
    
   # CREAMOS CONEXION. SI NO EXISTE LA BASE SE CREARA
    nombre_base="restaurante"
    conexion = sqlite3.connect(nombre_base + ".db")
    cursor = conexion.cursor()
    
    tabla = "categorias"
    
    # Recuperamos los registros de la tabla categoria
    
    categorias = cursor.execute("SELECT * FROM {}".format(tabla)).fetchall()
    
    for categoria in categorias:
        print("{}. {}".format(categoria[0],categoria[1]))

    cat_id = int(input("> "))
    
    plato = input("Ahora inserte el nombre del plato:\n> ")
    campo_update = "'nombre', 'categoria_id'"
    # INSERTAMOS EL PLATO EN LA BASE

    try:
        tabla = "platos"
        cursor.execute("INSERT INTO {} ({}) VALUES ('{}','{}')".format(tabla, campo_update, plato, cat_id))
    
        # print(categoria)
        # return
    except sqlite3.Error as e:
        messageError = e.args[0]
        
        if "UNIQUE" in messageError:
            print("\nNo puede insertar valores duplicados, '{}'\n".format(plato))
    else:
        mensaje = "\nSe ha agregado correctamente el plato {}.\n".format(plato)
        print(mensaje)
        conexion.commit()
        
    cursor.close()
    conexion.close()  
    
def mostrar_menu():
      # CREAMOS CONEXION. SI NO EXISTE LA BASE SE CREARA
    nombre_base="restaurante"
    conexion = sqlite3.connect(nombre_base + ".db")
    cursor = conexion.cursor()
    tabla_cat = "categorias"
    tabla_pla = "platos"
    
    categorias = cursor.execute("SELECT * FROM {}".format(tabla_cat)).fetchall()
    
    for categoria in categorias:
        print(categoria[1])
        platos = cursor.execute("SELECT * FROM {} WHERE categoria_id={}".format(tabla_pla, categoria[0])).fetchall()
        for plato in platos:
            print("\t{}".format(plato[1]))

    print()
    cursor.close()
    conexion.close() 

def main():
    
    #crear_db()
    while True:
        mensajeBienvenida = "Bienvenido al gestor de menús."

        print(mensajeBienvenida)
        respuesta=input("Indique que acción a realizar:\n\t1. Crear categoría.\n\t2. Añadir plato.\n\t3. Mostrar menú.\n\t4. Salir.\n\n> ")
        
        if respuesta == "1":
            agregar_categoria()
        elif respuesta == "2":
            agregar_plato()
        elif respuesta == "3":
            mostrar_menu()
        elif respuesta == "4":
            print("Hasta otra.")
            break
        else:
            print("""\nHa elegido una opción errónea. Debe elegir entre 1 y 2.\n""")
            os.system('cls' if os.name == 'nt' else 'clear')
    
main()
#agregar_plato()
#crear_db()