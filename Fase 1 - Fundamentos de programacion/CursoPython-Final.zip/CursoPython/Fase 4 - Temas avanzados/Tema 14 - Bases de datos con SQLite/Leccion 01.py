# -*- coding: utf-8 -*-
"""
Created on Wed Jan 22 20:48:38 2020

@author: Isra
"""

import sqlite3

# Creamos una conexion

conexion = sqlite3.connect("ejemplo.db")

# Crear estructura
cursor = conexion.cursor()

# Definicion de campos
campos = '\
nombre VARCHAR(100),\
edad INTEGER,\
email VARCHAR(100)'

tabla="usuarios"

try: # De esta manera ignoramos el error
    cursor.execute("CREATE TABLE " + tabla + " (" + campos + ")")
except sqlite3.Error as error:
    print("Ya existe la base de datos.", error)
finally:
    cursor.close()
    conexion.close()

# Ejecutamos una consulta de anexado
conexion = sqlite3.connect("ejemplo.db")
cursor = conexion.cursor()
    
camposAnexar= "nombre, edad, email" 
valoresAnexar = "'Hector', 27,'hector@gmail.com'"

try: # De esta manera ignoramos el error    
    cursor.execute("INSERT INTO " + tabla + " (" + camposAnexar + ") VALUES (" + valoresAnexar + ")")
    conexion.commit()
except sqlite3.Error as error:
    print("Error al insertar el dato.", error)
finally:
    cursor.close()    
    conexion.close()

# Si ocurre un error del tipo: OperationalError: database is locked; es posible que se haya ejecutado y 
# terminado en excepcion sin haber cerrado la conexion, o tenga la base abierta y no haya guardado los cambios.