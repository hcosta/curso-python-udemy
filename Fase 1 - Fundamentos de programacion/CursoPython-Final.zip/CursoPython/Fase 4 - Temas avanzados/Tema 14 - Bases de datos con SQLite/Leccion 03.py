# -*- coding: utf-8 -*-
"""
Created on Thu Jan 23 19:32:09 2020

@author: Isra
"""

import sqlite3
import sys

# Creamos una conexion
tabla ="usuarios"
nombrebase= "usuarios_autoincremental"
conexion = sqlite3.connect(nombrebase + ".db")
cursor = conexion.cursor()

cursor.execute("SELECT * FROM USUARIOS WHERE edad=27")

usuario = cursor.fetchall()
print(usuario)

conexion.commit()
cursor.close()
conexion.close()