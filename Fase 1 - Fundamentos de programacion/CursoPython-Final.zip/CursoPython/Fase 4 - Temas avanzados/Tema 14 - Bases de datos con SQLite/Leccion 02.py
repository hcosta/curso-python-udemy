# -*- coding: utf-8 -*-
"""
Created on Thu Jan 23 19:32:09 2020

@author: Isra
"""

import sqlite3
import sys

# Creamos una conexion
tabla ="usuarios"
conexion = sqlite3.connect(tabla + ".db")
cursor = conexion.cursor()

try:
    cursor.execute("\
        CREATE TABLE " + tabla + """ (
            dni VARCHAR(9) PRIMARY KEY,
            nombre VARCHAR(100),
            edad INTEGER,
            email VARCHAR(50)
            )""")
except sqlite3.Error as e:
    print(e, sys.exc_info()[0])
    #template = "Ha ocurrido una excepción de tipo {0} . Argumentos:\n{1!r}"
    #message = template.format(type(e).__name__, e.args)
    #print(message)
    
camposAnexar= "dni, nombre, edad, email" 
# usuarios = [
#     ('00000000X','Hector', 27, 'hector@gmail.com'),
#     ('11111111A','Mario', 51, 'mario@gmail.com'),
#     ('22222222B','Mercedes', 38, 'mercedes@gmail.com'),
#     ('33333333C','Juan', 19, 'juan@gmail.com')    
#     ]

# try:
#     cursor.executemany("INSERT INTO " + tabla + " (" + camposAnexar + " ) VALUES (?,?,?,?)", usuarios)
# except sqlite3.Error as e:
#     print(e, sys.exc_info()[0])

valoresAnexar = "'00000001A','Hector', 27, 'hector@gmail.com'"
#cursor.execute("INSERT INTO " + tabla + " (" + camposAnexar + ") VALUES (" + valoresAnexar + ")")



conexion.commit()
cursor.close()
conexion.close()