# -*- coding: utf-8 -*-
"""
Created on Thu Jan 23 19:32:09 2020

@author: Isra
"""

import sqlite3
import sys

# Creamos una conexion
tabla ="usuarios"
nombrebase= "usuarios_autoincremental"
conexion = sqlite3.connect(nombrebase + ".db")
cursor = conexion.cursor()

# CONSULTAS DE ELIMINACION
# Si no se especifica el where se borraran todos los registros.
cursor.execute("DELETE FROM USUARIOS WHERE dni='00000000X'")

conexion.commit()
cursor.close()
conexion.close()