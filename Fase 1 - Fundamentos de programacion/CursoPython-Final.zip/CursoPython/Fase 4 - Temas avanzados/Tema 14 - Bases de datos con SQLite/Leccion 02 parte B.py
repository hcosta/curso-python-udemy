# -*- coding: utf-8 -*-
"""
Created on Thu Jan 23 19:32:09 2020

@author: Isra
"""

import sqlite3
import sys

# Creamos una conexion
tabla ="productos"
conexion = sqlite3.connect(tabla + ".db")
cursor = conexion.cursor()

try:
    cursor.execute("\
        CREATE TABLE " + tabla + """ (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre VARCHAR(100) NOT NULL,
            marca VARCHAR(50) NOT NULL,
            precio FLOAT NOT NULL
            )""")
except sqlite3.Error as e:
    print(e, sys.exc_info()[0])

productos = [
    ('Teclado', 'Logitech', 19.95),
    ('Monitor 19"', 'LG', 89.95)
    ]

camposAnexar= "nombre, marca, precio" 

# try:
#     cursor.executemany("INSERT INTO " + tabla + " (" + camposAnexar + " ) VALUES (?,?,?)", productos)
# except sqlite3.Error as e:
#     print(e, sys.exc_info()[0])

#Consultar
# cursor.execute("SELECT * FROM PRODUCTOS")

# productos = cursor.fetchall()

# for producto in productos:
#     print(producto)



conexion.commit()
cursor.close()
conexion.close()