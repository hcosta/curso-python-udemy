# Importa la función 'saludar'
from saludos import saludar

saludar()
