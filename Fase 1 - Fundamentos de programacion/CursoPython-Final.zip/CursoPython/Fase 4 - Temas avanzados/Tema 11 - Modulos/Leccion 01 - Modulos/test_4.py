# Importa todas las funciones del módulo 'saludos'.
import saludos

saludos.Saludo() #Creamos un objeto