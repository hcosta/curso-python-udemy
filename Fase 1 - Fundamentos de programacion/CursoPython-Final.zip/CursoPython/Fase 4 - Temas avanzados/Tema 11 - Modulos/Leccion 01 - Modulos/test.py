#Importa el módulo
import saludos

saludos.saludar()
