# Importa todas las funciones del módulo 'saludos'.
from saludos import *

saludar()
