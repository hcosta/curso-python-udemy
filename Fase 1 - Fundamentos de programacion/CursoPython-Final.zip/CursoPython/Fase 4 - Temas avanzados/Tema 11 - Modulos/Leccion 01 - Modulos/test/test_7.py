# Importa sólo la clase
import sys 

# for v in sys.path[:]:
#     if v == '..':
#         sys.path.remove(v)

if not ('..' in sys.path):
    sys.path.append('..')  # Los dos puntos hacen referencia al directorio anterior del arbol de directorio del archivo actul
    

print(sys.path)

from saludos import *

Saludo() #Creamos un objeto