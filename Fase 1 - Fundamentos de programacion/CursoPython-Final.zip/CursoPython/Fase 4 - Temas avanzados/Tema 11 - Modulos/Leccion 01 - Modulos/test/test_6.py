# Importa sólo la clase
from saludos import Saludo

Saludo() #Creamos un objeto