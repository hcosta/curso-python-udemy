# -*- coding: utf-8 -*-
"""
Created on Sat Jan 18 02:07:42 2020

@author: Isra
"""

import datetime
import os
import time

# Diseño del reloj
while True:
    os.system("cls") # linux usa 'clear'
    reloj = "{}:{}:{}"
    
    hora = datetime.datetime.now()
    info_reloj = reloj.format(hora.hour, hora.minute, hora.second)
    
    print(info_reloj)
    
    time.sleep(0.9)

    
    