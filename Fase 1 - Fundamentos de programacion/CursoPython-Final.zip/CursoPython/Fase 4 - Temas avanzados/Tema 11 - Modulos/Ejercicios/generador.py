# -*- coding: utf-8 -*-
"""
Created on Sat Jan 18 11:46:41 2020

@author: Isra
"""
import random
import math

def leer_numero(ini,fin,mensaje):
    while True:
        try:
            valor = int( input(mensaje) )
        except:
            pass
        else:
            if valor >= ini and valor <= fin:
                break
    return valor

def generador():
    numeros = leer_numero(1,20,"¿Cuantos números quieres generar? [1-20]: ")
    modo = leer_numero(1,3,"¿Cómo quieres redondear los números? [1]Al alza [2]A la baja [3]Normal: ")
    
    lista = []
    
    for i in range(numeros):
        numero = random.uniform(0,101)
        if modo == 1:
            numero_mod = math.ceil(numero)
            print("{} => {}".format(numero, numero_mod) )
        elif modo == 2:
            numero_mod = math.floor(numero)
            print("{} => {}".format(numero, numero_mod) )
        elif modo == 3:
            numero_mod = round(numero)
            print("{} => {}".format(numero, numero_mod) )  
            
        lista.append(numero)
        
    return lista

generador()