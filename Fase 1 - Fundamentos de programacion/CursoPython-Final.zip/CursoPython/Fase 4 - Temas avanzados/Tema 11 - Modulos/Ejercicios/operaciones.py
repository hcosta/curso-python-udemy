# -*- coding: utf-8 -*-
#from numbers import Number

def suma(a, b):
    try:
      r = a + b
    except TypeError:
        print("Sólo se permiten números como argumentos.")
    else:
        return r

def resta(a, b):
    try:
      r = a - b
    except TypeError:
        print("Sólo se permiten números como argumentos.")
    else:
        return r

def producto(a, b):
    try:
      r = a * b
    except TypeError:
        print("Sólo se permiten números como argumentos.")
    else:
        return r

def division(a, b):
    try:
      r = a / b
    except TypeError:
        print("Sólo se permiten números como argumentos.")
    except ZeroDivisionError:
        print("Error: no se puede dividir por cero.")        
    else:
        return r

# def sonNumeros(a, b):   
    
#     if isinstance(a, Number) and isinstance(b, Number):
#         return True
    
#     return False



