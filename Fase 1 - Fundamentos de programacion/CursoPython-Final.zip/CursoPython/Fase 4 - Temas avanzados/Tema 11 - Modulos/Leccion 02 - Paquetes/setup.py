# -*- coding: utf-8 -*-
# Definiremos una información básica
from setuptools import setup

setup(
      # Indicamos nombre de paquete
      name = "paquete",
      version = "0.1",
      description = "Este es un paquete de ejemplo",
      author = "Hector Costa",
      author_email = "y@gmail.com",
      url = "http://tokiskilasoba.com",
      script = [],
      packages = ['paquete', 'paquete.adios', 'paquete.hola']
      
      )

# Ahora hay que crear el setup.exe de instalación del paquete
# Para ello iremos al directorio del archivo setup.py
# Abrimos una consola de comandos, pulsando Ctrl+Shift+Right Button
# Y desde la consola de comandos ejecutamos la siguiente instrucción:
#              'python setup.py sdist'
# Nota: desde PowerShell aun no funciona esta llamada.

# Una vez creado el instalador, sólo falta instalarlo en python.
# Abrimos una consola de comandos, pulsando Ctrl+Shift+Right Button
# Usaremos la siguiente instrucción:
#             pip3 install paquete-0.1.tar.gz
# Si no funciona con pip3 probaremos con pip
# Para ver los paquetes instalados: pip list

# Para desinstalar el paquete ejecutamos la siguiente instrucción:
#             pip3 uninstall paquete
# Si no funciona con pip3 probaremos con pip