﻿from paquete.hola.saludos import saludar 
from paquete.adios.despedidas import Despedida 

saludar() 
Despedida()

# Al intentar usar los metodos y clase, dará un error porque no 
# encuentra los paquetes ni módulos.
# La manera de solventarlo sería transformar el paquete 
# en un paquete distribuible que podrá ser instalado dentro de
# python

# Tras instalar el paquete ya debería funcionar.