﻿# Este es un mÃ³dulo con funciones que saluda
def despedirse():
    print("Adiós, me despido desde la función despedirse del modulo despedidas.py")
    
#Redefinir clases
class Despedida():
    def __init__(self):
        print("Adiós, te estoy despidiendo desde le metodo __init__ de la clase Despedida")