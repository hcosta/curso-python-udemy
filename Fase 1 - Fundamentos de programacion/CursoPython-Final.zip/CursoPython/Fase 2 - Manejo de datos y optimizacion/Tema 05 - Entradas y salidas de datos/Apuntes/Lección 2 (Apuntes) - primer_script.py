# -*- coding: utf-8 -*-
"""
Created on Fri Jan 10 16:15:21 2020

@author: Isra
"""

import sys

print("Hola, bienvenido a tu primer script")
print(sys.argv)